﻿alert("chatbot.js loaded");
document.addEventListener("DOMContentLoaded", function () {

    const chatPanel =
        document.getElementById("chatbotPanel");

    const chatIcon =
        document.getElementById("chatbotToggle");

    const closeBtn =
        document.getElementById("closeChat");

    chatIcon.addEventListener("click", function () {

        chatPanel.style.display = "block";

    });

    closeBtn.addEventListener("click", function () {

        chatPanel.style.display = "none";

    });

}); const sendBtn =
    document.getElementById("sendBtn");

const chatBox =
    document.getElementById("chatBox");

const messageInput =
    document.getElementById("messageInput");

sendBtn.addEventListener("click", sendMessage);
messageInput.addEventListener(
    "keypress",
    function (e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    }
);

function sendMessage() {
    let message =
        messageInput.value.trim();

    if (message === "")
        return;

    addUserMessage(message);

    showTyping(message);

    messageInput.value = "";
}

function addUserMessage(message) {
    let div =
        document.createElement("div");

    div.innerHTML =
        `
                            <div style="
                                text-align:right;
                                margin-bottom:10px;">

                                <span style="
                                    background:#2563eb;
                                    color:white;
                                    padding:10px 14px;
                                    border-radius:15px;
                                    display:inline-block">

                                    ${message}

                                </span>

                            </div>
                        `;

    chatBox.appendChild(div);
}

function addBotMessage(message) {
    let div =
        document.createElement("div");

    div.className =
        "bot-message";

    div.innerHTML =
        `
                            <div style="
                            text-align:left;
                            margin-bottom:10px;">

                                <span style="
                                    background:#f3f4f6;
                                    padding:10px 14px;
                                    border-radius:15px;
                                    display:inline-block;">

                                    🤖 ${message}

                                </span>

                            </div>
                        `;

    chatBox.appendChild(div);

    chatBox.scrollTop =
        chatBox.scrollHeight;
}

async function showTyping(message) {

    addBotMessage("Typing...");

    setTimeout(async function () {

        let messages =
            document.querySelectorAll("#chatBox .bot-message");

        if (messages.length > 0) {
            messages[messages.length - 1].remove();
        }

        try {

            const response = await fetch("http://localhost:5052/api/AI/chat", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    prompt: message
                })

            });

            const data = await response.json();

            addBotMessage(data.response);

        }
        catch (err) {

            console.error(err);

            addBotMessage("Unable to contact AI server.");

        }

    }, 1000);

}
window.onload = function () {
    addBotMessage(
        "Welcome to SmartKart AI Assistant. How can I help you today?"
    );
};
function fillQuestion(text) {
    document.getElementById("messageInput").value = text;

    sendMessage();
}